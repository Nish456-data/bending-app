import streamlit as st

machine = {
    "max_length": 3100,
    "max_tonnage": 110,
    "dies": [7, 8, 12]
}

def select_die(thickness):
    required_v = thickness * 6
    possible = [v for v in machine["dies"] if v >= required_v]
    return min(possible) if possible else None

def tonnage_calc(t, V, length):
    return (1.42 * t**2 / V) * (length / 1000)

def flange_check(flange, V):
    min_f = 0.7 * V
    if flange < min_f:
        return "FAIL"
    elif flange < min_f * 1.2:
        return "RISK"
    return "OK"

def detect_offset(flanges):
    for i in range(len(flanges)-1):
        if abs(flanges[i] - flanges[i+1]) < 10:
            return True
    return False

st.title("🔧 Bending Feasibility App")

material = st.selectbox("Material", ["MS", "SS", "Aluminum"])
thickness = st.selectbox("Thickness (mm)", [1.0, 1.2, 1.5, 2.0, 3.0])
length = st.number_input("Bend Length (mm)", value=100)

f1 = st.number_input("Flange 1", value=6)
f2 = st.number_input("Flange 2", value=12)
f3 = st.number_input("Flange 3", value=30)

flanges = [f1, f2, f3]

if st.button("Check Feasibility"):

    die = select_die(thickness)

    if not die:
        st.error("❌ No suitable die")
    else:
        ton = tonnage_calc(thickness, die, length)

        warnings = []

        for f in flanges:
            status = flange_check(f, die)
            if status == "FAIL":
                warnings.append(f"Flange {f} too small")
            elif status == "RISK":
                warnings.append(f"Flange {f} risky")

        if detect_offset(flanges):
            warnings.append("Offset bend detected")

        if any(f < 10 for f in flanges):
            warnings.append("Tool collision risk")

        if ton > machine["max_tonnage"]:
            warnings.append("Over tonnage")

        if warnings:
            st.warning("⚠️ CONDITIONALLY FEASIBLE")
        else:
            st.success("✅ FEASIBLE")

        st.write(f"**Die:** V{die}")
        st.write(f"**Tonnage:** {round(ton,2)} Ton")

        st.subheader("Warnings")
        for w in warnings:
            st.write("- " + w)

        st.subheader("Bend Sequence")
        for i, f in enumerate(sorted(flanges)):
            st.write(f"{i+1}. Bend {f} mm")
